import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import muambaImage from "@/assets/muamba.jpg";
import caluluImage from "@/assets/calulu.jpg";
import fungeImage from "@/assets/funge.jpg";
import mufeteImage from "@/assets/mufete.jpg";

const menuItems = [
  {
    name: "Muamba de Galinha",
    description: "Ensopado tradicional de frango em molho de óleo de palma, servido com funge",
    price: "3.500 Kz",
    image: muambaImage,
    popular: true,
  },
  {
    name: "Calulu",
    description: "Guisado de peixe seco com vegetais frescos e batata-doce",
    price: "3.200 Kz",
    image: caluluImage,
    popular: false,
  },
  {
    name: "Funge",
    description: "Acompanhamento tradicional de farinha de mandioca ou milho",
    price: "800 Kz",
    image: fungeImage,
    popular: false,
  },
  {
    name: "Mufete",
    description: "Peixe grelhado acompanhado de banana-pão e batata-doce",
    price: "4.000 Kz",
    image: mufeteImage,
    popular: true,
  },
];

const Menu = () => {
  return (
    <section className="py-24 bg-muted/30" id="menu">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-4">
            Nosso Cardápio
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto mb-6" />
          <p className="font-inter text-lg text-muted-foreground max-w-2xl mx-auto">
            Pratos tradicionais angolanos preparados com ingredientes frescos e autênticos
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {menuItems.map((item) => (
            <Card 
              key={item.name}
              className="overflow-hidden border-border bg-card hover:shadow-[var(--shadow-warm)] transition-all duration-300 hover:scale-[1.02] group"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                {item.popular && (
                  <Badge className="absolute top-4 right-4 bg-primary text-primary-foreground font-semibold">
                    Popular
                  </Badge>
                )}
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-playfair text-2xl font-bold text-card-foreground">
                    {item.name}
                  </h3>
                  <span className="font-playfair text-xl font-bold text-primary whitespace-nowrap ml-4">
                    {item.price}
                  </span>
                </div>
                <p className="font-inter text-muted-foreground leading-relaxed">
                  {item.description}
                </p>
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="font-inter text-muted-foreground">
            *Todos os pratos são servidos com acompanhamentos tradicionais
          </p>
        </div>
      </div>
    </section>
  );
};

export default Menu;
