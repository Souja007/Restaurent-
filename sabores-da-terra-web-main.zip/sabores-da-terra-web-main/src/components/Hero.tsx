import { Button } from "@/components/ui/button";
import { MapPin, Phone } from "lucide-react";
import heroImage from "@/assets/hero-dish.jpg";

const Hero = () => {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80" />
      </div>
      
      <div className="relative z-10 container mx-auto px-4 text-center">
        <h1 className="font-playfair text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 animate-fade-in">
          Sabores da Terra
        </h1>
        <p className="font-inter text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
          Autêntica culinária angolana no coração de Luanda
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button 
            size="lg" 
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-lg px-8 py-6 rounded-lg shadow-[var(--shadow-warm)] transition-all hover:scale-105"
            onClick={() => scrollToSection("menu")}
          >
            Ver Cardápio
          </Button>
          <Button 
            size="lg"
            variant="outline"
            className="bg-white/10 backdrop-blur-sm border-2 border-white text-white hover:bg-white hover:text-foreground font-semibold text-lg px-8 py-6 rounded-lg transition-all hover:scale-105"
            onClick={() => scrollToSection("location")}
          >
            Reservar Mesa
          </Button>
        </div>
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center text-white/80">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            <span className="font-inter">Luanda, Angola</span>
          </div>
          <div className="hidden sm:block text-white/40">|</div>
          <div className="flex items-center gap-2">
            <Phone className="w-5 h-5" />
            <span className="font-inter">+244 923 456 789</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
