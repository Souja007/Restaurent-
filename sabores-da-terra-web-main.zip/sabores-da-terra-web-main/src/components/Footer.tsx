import { Facebook, Instagram, Mail, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="font-playfair text-2xl font-bold mb-4">
              Sabores da Terra
            </h3>
            <p className="font-inter text-secondary-foreground/80 mb-4">
              Autêntica culinária angolana no coração de Luanda desde 2010.
            </p>
            <div className="flex gap-4">
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-playfair text-xl font-bold mb-4">
              Links Rápidos
            </h4>
            <ul className="font-inter space-y-2">
              <li>
                <a href="#about" className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors">
                  Sobre Nós
                </a>
              </li>
              <li>
                <a href="#menu" className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors">
                  Cardápio
                </a>
              </li>
              <li>
                <a href="#location" className="text-secondary-foreground/80 hover:text-secondary-foreground transition-colors">
                  Localização
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-playfair text-xl font-bold mb-4">
              Contato
            </h4>
            <ul className="font-inter space-y-3">
              <li className="flex items-center gap-2 text-secondary-foreground/80">
                <Phone className="w-4 h-4" />
                <span>+244 923 456 789</span>
              </li>
              <li className="flex items-center gap-2 text-secondary-foreground/80">
                <Mail className="w-4 h-4" />
                <span>contato@saboresdaterra.ao</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 text-center">
          <p className="font-inter text-secondary-foreground/60">
            © 2024 Sabores da Terra. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
