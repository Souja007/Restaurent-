import { Card } from "@/components/ui/card";
import { Heart, Users, Award } from "lucide-react";
import interiorImage from "@/assets/restaurant-interior.jpg";

const About = () => {
  return (
    <section className="py-24 bg-background" id="about">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-4">
            Sobre Nós
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-primary to-accent mx-auto mb-6" />
          <p className="font-inter text-lg text-muted-foreground max-w-2xl mx-auto">
            Uma jornada pelos sabores autênticos de Angola
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl">
            <img 
              src={interiorImage} 
              alt="Interior do restaurante Sabores da Terra"
              className="w-full h-[500px] object-cover"
            />
          </div>
          
          <div className="space-y-6">
            <h3 className="font-playfair text-3xl font-bold text-foreground">
              A Nossa História
            </h3>
            <p className="font-inter text-muted-foreground leading-relaxed">
              O Sabores da Terra nasceu do sonho de compartilhar a riqueza gastronómica de Angola 
              com o mundo. Desde 2010, temos o privilégio de servir pratos tradicionais preparados 
              com receitas passadas de geração em geração.
            </p>
            <p className="font-inter text-muted-foreground leading-relaxed">
              Cada prato conta uma história, cada sabor evoca memórias. Utilizamos ingredientes 
              frescos e locais para garantir a autenticidade que você merece. Nossa missão é 
              proporcionar uma experiência culinária inesquecível.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="p-8 text-center border-border bg-card hover:shadow-[var(--shadow-warm)] transition-all duration-300 hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h4 className="font-playfair text-xl font-bold text-card-foreground mb-2">
              Feito com Amor
            </h4>
            <p className="font-inter text-muted-foreground">
              Cada prato é preparado com dedicação e paixão pela culinária angolana
            </p>
          </Card>

          <Card className="p-8 text-center border-border bg-card hover:shadow-[var(--shadow-warm)] transition-all duration-300 hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-br from-secondary to-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h4 className="font-playfair text-xl font-bold text-card-foreground mb-2">
              Família Unida
            </h4>
            <p className="font-inter text-muted-foreground">
              Mais de 13 anos servindo famílias e criando memórias especiais
            </p>
          </Card>

          <Card className="p-8 text-center border-border bg-card hover:shadow-[var(--shadow-warm)] transition-all duration-300 hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-br from-accent to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h4 className="font-playfair text-xl font-bold text-card-foreground mb-2">
              Qualidade Premium
            </h4>
            <p className="font-inter text-muted-foreground">
              Ingredientes frescos e receitas tradicionais autênticas
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default About;
